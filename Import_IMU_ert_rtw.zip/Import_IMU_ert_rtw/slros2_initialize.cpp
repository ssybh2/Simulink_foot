// Copyright 2022-2023 The MathWorks, Inc.
// Generated 29-Jun-2026 19:33:01
#include "slros2_initialize.h"
// Import_IMU/Subsystem/Publish1
SimulinkPublisher<custom_msgs::msg::WriteDmMotorMITControl,SL_Bus_custom_msgs_WriteDmMotorMITControl> Pub_Import_IMU_208;
// Import_IMU/Subsystem/Publish2
SimulinkPublisher<custom_msgs::msg::WriteDmMotorMITControl,SL_Bus_custom_msgs_WriteDmMotorMITControl> Pub_Import_IMU_209;
// Import_IMU/Subsystem1/Publish1
SimulinkPublisher<custom_msgs::msg::WriteDmMotorMITControl,SL_Bus_custom_msgs_WriteDmMotorMITControl> Pub_Import_IMU_245;
// Import_IMU/Subsystem1/Publish2
SimulinkPublisher<custom_msgs::msg::WriteDmMotorMITControl,SL_Bus_custom_msgs_WriteDmMotorMITControl> Pub_Import_IMU_246;
// Import_IMU/IMU
SimulinkSubscriber<sensor_msgs::msg::Imu,SL_Bus_sensor_msgs_Imu> Sub_Import_IMU_74;
// Import_IMU/Subscribe_Motor1_LA
SimulinkSubscriber<custom_msgs::msg::ReadDmMotor,SL_Bus_custom_msgs_ReadDmMotor> Sub_Import_IMU_1;
// Import_IMU/Subscribe_Motor2_LB
SimulinkSubscriber<custom_msgs::msg::ReadDmMotor,SL_Bus_custom_msgs_ReadDmMotor> Sub_Import_IMU_2;
// Import_IMU/Subscribe_Motor3_RA
SimulinkSubscriber<custom_msgs::msg::ReadDmMotor,SL_Bus_custom_msgs_ReadDmMotor> Sub_Import_IMU_3;
// Import_IMU/Subscribe_Motor4_RB
SimulinkSubscriber<custom_msgs::msg::ReadDmMotor,SL_Bus_custom_msgs_ReadDmMotor> Sub_Import_IMU_4;
// Import_IMU/Switch/Subscribe
SimulinkSubscriber<custom_msgs::msg::ReadDJIRC,SL_Bus_custom_msgs_ReadDJIRC> Sub_Import_IMU_104;
